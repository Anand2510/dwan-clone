
  var page = 2; // Initial page number
  var loading = false; // Flag to prevent multiple requests

  function loadMoreProducts() {
    if (!loading) {
      loading = true;

      var url = '/collection/{{ collection.handle }}?page=' + page + ' #infinite-scroll-container';

      $.ajax({
        url: url,
        type: 'GET',
        dataType: 'html',
        success: function (data) {
          var products = $(data).find('#infinite-scroll-container .product');
          if (products.length > 0) {
            $('#infinite-scroll-container').append(products);
            page++;
            loading = false;
          } else {
            // No more products, remove the infinite scroll event
            $(window).off('scroll', scrollHandler);
          }
        },
        error: function (error) {
          console.log('Error loading more products');
          loading = false;
        }
      });
    }
  }

  function scrollHandler() {
    if ($(window).scrollTop() + $(window).height() > $(document).height() - 200) {
      loadMoreProducts();
    }
  }

  // Attach the scroll handler
  $(window).on('scroll', scrollHandler);

