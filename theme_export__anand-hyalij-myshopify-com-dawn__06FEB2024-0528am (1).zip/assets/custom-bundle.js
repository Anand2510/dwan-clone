$(document).ready(function () {
    var maxImages = 4;
    var imageAdded = false;

    $(".cookie img").click(function () {
        var imageUrl = $(this).attr('src');
        var imageText = $(this).attr('alt');
        console.log(imageText);
        var currentImageCount = $(".pro-color img").length;

        if (currentImageCount < maxImages) {
            var appendedImage = "<div class='appended-image' style='width: 50px;'><img src='" + imageUrl + "' alt='Appended image' style='width: 200px;'>";
            
            // Dynamically set the value of hidden input with unique ID based on the click count
            var appendText = $('#customerName' + (currentImageCount + 1)).val(imageText);

            appendedImage += "<span class='close-icon'>&times;</span></div>";
            $(".pro-color").append(appendedImage, appendText);
            imageAdded = true;
        }
    });

    $(".pro-color").on("click", ".close-icon", function () {
        $(this).parent().remove();
        imageAdded = $(".pro-color img").length > 0;
    });

    $('#ProductSubmitButton-template--15417639796825__main').click(function () {
        if (!imageAdded) {
            alert("Please add at least one image before clicking 'Add to Cart'.");
                // $('#ProductSubmitButton-template--15417639796825__main').empty();
           $("#cart-icon-bubble .cart-count-bubble").remove();
              // $("#cart-icon-bubble .visually-hidden").after('<div class="cart-count-bubble">'+updatedQuantity+'</div>'); 
              $('cart-drawer').load(window.location.href + ' #CartDrawer');
              $('#CartDrawer').removeClass('is-empty');
        }
    });
});





// $(document).ready(function(){
//   $('#ProductSubmitButton-template--15417639796825__main').click(function(){
//      alert("hello");
//   });
 
// });



  // <p class="line-item-property__field">
  //                 <label for="customerName">Customer Name:</label>
  //                 <input id="customerName" type="text" name="properties[customerName]" form="product-form-{{ section.id }}">
  //           </p>

// $('body').on('click', '.open img ', function() {
//       var Get_img = $(this).attr('src');
      
//       $(".popup-overlay .popup-content img").attr('src', Get_img)
//       // console.log(Get_img);

//       var Get_p = $(this).attr('data-text');
      
//       $(".popup-overlay .popup-content p").text(Get_p)
//   // console.log(Get_p);
//       $(".popup-overlay, .popup-content").addClass("active");
//     });
    
//     //removes the "active" class to .popup and .popup-content when the "Close" button is clicked 
//     $(".close, .popup-overlay").on("click", function() {
//       $(".popup-overlay, .popup-content").removeClass("active");
//     });
